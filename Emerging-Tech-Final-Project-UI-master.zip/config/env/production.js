// Set the 'production' environment configuration object
module.exports = {
	db: 'mongodb://localhost/mean-production', //Replace with Database name
	sessionSecret: 'productionSessionSecret'
};